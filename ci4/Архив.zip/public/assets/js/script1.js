function hello(){
    alert("Hello!");
}